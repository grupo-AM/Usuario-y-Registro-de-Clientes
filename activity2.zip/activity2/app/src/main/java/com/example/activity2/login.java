package com.example.activity2;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.google.android.material.textfield.TextInputEditText;
import com.google.android.material.textfield.TextInputLayout;

import org.json.JSONArray;
import org.json.JSONException;

public class login extends AppCompatActivity {
    private TextInputEditText etUsuario;
    private TextInputEditText etClave;
    private Button buttonIngresar;
    private TextInputLayout tilUsuario;
    private TextInputLayout tilClave;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_login);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
        etUsuario = findViewById(R.id.editTextUsername);
        etClave = findViewById(R.id.editTextPassword);
        buttonIngresar = findViewById(R.id.buttonLogin);
        tilUsuario = findViewById(R.id.tilUsuario);
        tilClave = findViewById(R.id.tilClave);
    }

    public void btIngresar(View v) {
        String usuario = etUsuario.getText().toString();
        String clave = etClave.getText().toString();

        boolean esValido = true;

        if (usuario.isEmpty()) {
            tilUsuario.setError("Nombre requerido");
            esValido = false;
        } else {
            tilUsuario.setError(null);
        }

        if (clave.isEmpty()) {
            tilClave.setError("Clave requerida");
            esValido = false;
        } else {
            tilClave.setError(null);
        }

        if (esValido) {
            RequestQueue queue = Volley.newRequestQueue(this);
            String url = "https://revistas.uteq.edu.ec/ws/login.php?usr=" + usuario + "&pass=" + clave;

            StringRequest stringRequest = new StringRequest(Request.Method.GET, url,
                    new Response.Listener<String>() {
                        @Override
                        public void onResponse(String response) {
                            try {
                                // El servidor devuelve un Array JSON, si tiene datos, el login es correcto
                                JSONArray jsonArray = new JSONArray(response);
                                if (jsonArray.length() > 0) {
                                    Toast.makeText(login.this, "Login Exitoso", Toast.LENGTH_SHORT).show();
                                    // Asumiendo que listabanco.class existe, si no, reemplaza o elimina
                                    // Intent intent = new Intent(login.this, listabanco.class);
                                    // startActivity(intent);
                                    // finish();
                                } else {
                                    // Si el array está vacío, el usuario o clave son incorrectos
                                    Toast.makeText(login.this, "Usuario o clave incorrectos", Toast.LENGTH_LONG).show();
                                }
                            } catch (JSONException e) {
                                // Si la respuesta no es un JSON válido, muéstrala
                                Toast.makeText(login.this, "Error en la respuesta: " + response, Toast.LENGTH_LONG).show();
                            }
                        }
                    }, new Response.ErrorListener() {
                @Override
                public void onErrorResponse(VolleyError error) {
                    // Muestra un error más detallado
                    Toast.makeText(login.this, "Error de conexión: " + error.toString(), Toast.LENGTH_LONG).show();
                }
            });

            queue.add(stringRequest);
        }
    }
}
